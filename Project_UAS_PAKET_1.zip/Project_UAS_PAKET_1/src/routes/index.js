const router = require('express').Router();
const routeObat = require('./obat');
const routeSupplier = require('./supplier'); 
const routePelanggan = require('./pelanggan'); 
const routeKaryawan = require('./karyawan'); 
const routeFaktur_supply = require('./faktur_supply'); 
const routeFaktur_penjualan = require('./faktur_penjualan');


// GET localhost:8080/kelas => Ambil data semua kelas
router.use('/obat', routeObat);
router.use('/supplier', routeSupplier); 
router.use('/pelanggan', routePelanggan); 
router.use('/karyawan', routeKaryawan); 
router.use('/faktur_supply', routeFaktur_supply); 
router.use('/faktur_penjualan', routeFaktur_penjualan);



module.exports = router;