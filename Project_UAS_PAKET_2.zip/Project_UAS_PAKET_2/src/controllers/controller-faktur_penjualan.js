const config = require('../configs/database');
const mysql = require('mysql');
const connection = mysql.createConnection(config);
connection.connect();

// menampilkan semua data
const getDatafaktur_penjualan = async(req, res) => {
    const data = await new Promise((resolve, reject) => {
        connection.query('SELECT * FROM faktur_penjualan', function(error, rows) {
            if (rows) {
                resolve(rows);
            } else {
                reject([]);
            }
        });
    });

    if (data) {
        res.send({
            success: true,
            message: 'Berhasil ambil data!',
            data: data
        });
    } else {
        res.send({
            success: false,
            message: 'Gagal ambil data!',
        });
    }
}

// manambahkan data
const addDatafaktur_penjualan= async(req, res) => {
    let data = { 
        id: req.body.id,
        tanggal: req.body.tanggal, 
        id_pelanggan: req.body.id_pelanggan, 
        id_karyawan: req.body.id_karyawan, 
        id_obat: req.body.id_obat, 
        jumlah: req.body.jumlah, 
        total: req.body.total, 
        pajak: req.body.pajak, 
        total_bayar: req.body.total_bayar
    }
    const result = await new Promise((resolve, reject) => {
        connection.query('INSERT INTO faktur_penjualan SET ?;', [data], function(error, rows) {
            if (rows) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil menambahkan data!'
        });
    } else {
        res.send({
            success: false,
            message: 'Gagal menambahkan data!',
        });
    }
}

//mengubah data
const editDatafaktur_penjualan = async(req, res) => {
    let id = req.params.id;
    let dataEdit = { 
        id: req.body.id,
        tanggal: req.body.tanggal, 
        id_pelanggan: req.body.id_pelanggan, 
        id_karyawan: req.body.id_karyawan, 
        id_obat: req.body.id_obat, 
        jumlah: req.body.jumlah, 
        total: req.body.total, 
        pajak: req.body.pajak, 
        total_bayar: req.body.total_bayar
    }

    const result = await new Promise((resolve, reject) => {
        connection.query('UPDATE faktur_penjualan SET ? WHERE id = ?;', [dataEdit, id], function(error, rows) {
            if (rows) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil edit data!'
        });
    } else {
        res.send({
            success: false,
            message: 'Gagal edit data'
        });
    }
}

//menghapus data
const deleteDatafaktur_penjualan= async(req, res) => {
    let id = req.params.id;

    const result = await new Promise((resolve, reject) => {
        connection.query('DELETE FROM faktur_penjualan WHERE id = ?;', [id], function(error, rows) {
            if (rows) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil hapus data!'
        });
    } else {
        res.send({
            success: false,
            message: 'Gagal menghapus data!'
        });
    }
}

module.exports = {
    getDatafaktur_penjualan,
    addDatafaktur_penjualan,
    editDatafaktur_penjualan,
    deleteDatafaktur_penjualan
}