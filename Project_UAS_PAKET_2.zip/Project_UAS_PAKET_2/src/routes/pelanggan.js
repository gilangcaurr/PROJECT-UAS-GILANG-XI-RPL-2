const router = require('express').Router();
const { pelanggan } = require('../controllers');

// GET localhost:8080/pelanggan=> Ambil data semuapelanggan
router.get('/',pelanggan.getDatapelanggan);

// // POST localhost:8080/pelanggan/add => Tambah datapelangganke database
router.post('/add',pelanggan.addDatapelanggan);

// // POST localhost:8080/pelanggan/2 => Edit datapelanggan
router.put('/edit/:id',pelanggan.editDatapelanggan);

// // POST localhost:8080/pelanggan/delete => Delete datapelanggan
router.delete('/delete/:id',pelanggan.deleteDatapelanggan);

module.exports = router;