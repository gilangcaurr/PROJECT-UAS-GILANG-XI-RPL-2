const router = require('express').Router();
const { faktur_supply } = require('../controllers');

// GET localhost:8080/faktur_supply=> Ambil data semuafaktur_supply
router.get('/',faktur_supply.getDatafaktur_supply);

// // POST localhost:8080/faktur_supply/add => Tambah datafaktur_supplyke database
router.post('/add',faktur_supply.addDatafaktur_supply);

// // POST localhost:8080/faktur_supply/2 => Edit datafaktur_supply
router.put('/edit/:id',faktur_supply.editDatafaktur_supply);

// // POST localhost:8080/faktur_supply/delete => Delete datafaktur_supply
router.delete('/delete/:id',faktur_supply.deleteDatafaktur_supply);

module.exports = router;