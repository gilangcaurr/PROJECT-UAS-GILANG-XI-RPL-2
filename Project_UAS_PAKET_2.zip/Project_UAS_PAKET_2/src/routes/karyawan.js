const router = require('express').Router();
const { karyawan } = require('../controllers');

// GET localhost:8080/karyawan=> Ambil data semuakaryawan
router.get('/',karyawan.getDatakaryawan);

// // POST localhost:8080/karyawan/add => Tambah datakaryawanke database
router.post('/add',karyawan.addDatakaryawan);

// // POST localhost:8080/karyawan/2 => Edit datakaryawan
router.put('/edit/:id',karyawan.editDatakaryawan);

// // POST localhost:8080/karyawan/delete => Delete datakaryawan
router.delete('/delete/:id',karyawan.deleteDatakaryawan);

module.exports = router;