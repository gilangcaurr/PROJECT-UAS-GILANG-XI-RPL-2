const router = require('express').Router();
const { obat } = require('../controllers');

// GET localhost:8080/obat=> Ambil data semuaobat
router.get('/',obat.getDataobat);

// // POST localhost:8080/obat/add => Tambah dataobatke database
router.post('/add',obat.addDataobat);

// // POST localhost:8080/obat/2 => Edit dataobat
router.put('/edit/:id',obat.editDataobat);

// // POST localhost:8080/obat/delete => Delete dataobat
router.delete('/delete/:id',obat.deleteDataobat);

module.exports = router;