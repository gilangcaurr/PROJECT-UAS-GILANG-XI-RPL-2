const router = require('express').Router();
const { faktur_penjualan } = require('../controllers');

// GET localhost:8080/faktur_penjualan=> Ambil data semuafaktur_penjualan
router.get('/',faktur_penjualan.getDatafaktur_penjualan);

// // POST localhost:8080/faktur_penjualan/add => Tambah datafaktur_penjualanke database
router.post('/add',faktur_penjualan.addDatafaktur_penjualan);

// // POST localhost:8080/faktur_penjualan/2 => Edit datafaktur_penjualan
router.put('/edit/:id',faktur_penjualan.editDatafaktur_penjualan);

// // POST localhost:8080/faktur_penjualan/delete => Delete datafaktur_penjualan
router.delete('/delete/:id',faktur_penjualan.deleteDatafaktur_penjualan);

module.exports = router;